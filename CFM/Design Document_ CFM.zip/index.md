# Design Document: CFM

# Cloud File Manager with ML Metadata Analysis

## Design Document

**Version:**&#x31;.0
**Date:**&#x4D;arch 03, 2025
**Author:**&#x43;laude

## 1. Executive Summary

The Cloud File Manager is a serverless application designed to provide secure file storage, intelligent metadata extraction, and advanced search capabilities. This system leverages AWS free tier services to allow users to upload, analyze, and search files while maintaining zero cost. The system automatically extracts meaningful metadata from uploaded files using machine learning techniques and provides an intuitive interface for users to interact with their files.

This document outlines the architecture, components, data flow, security measures, and implementation details for building a robust cloud file management system that meets the following key requirements:

* Serverless architecture utilizing AWS free tier services
* Secure file storage with validation and virus scanning
* Intelligent metadata extraction using ML services
* High-performance search capabilities
* Zero-cost operation

## 2. System Overview

### 2.1 System Purpose

The Cloud File Manager system allows users to:

* Upload files through a web interface or CLI
* Automatically extract and analyze file metadata
* Search for files based on content, metadata, and other attributes
* Securely store and manage files in the cloud
* Gain insights about their data through ML-powered analysis

### 2.2 High-Level Architecture

The system follows a serverless microservices architecture with the following main components:

1. **Storage Layer**: S3 for file storage and DynamoDB for metadata
2. **Compute Layer**: Lambda functions for event-driven processing
3. **API Layer**: API Gateway for RESTful interface
4. **ML Pipeline**: Rekognition, Textract, and custom ML models for analysis
5. **Security Layer**: IAM, presigned URLs, and virus scanning
6. **Client Layer**: Web interface and CLI tools

### 2.3 Key Features

* Secure file upload and storage
* Automatic metadata extraction (text, entities, labels)
* Content-based search
* Virus scanning
* Document classification
* Custom metadata generation

## 3. Detailed Architecture Design

### 3.1 System Architecture Diagram

The architecture follows a serverless event-driven design with the following components:



![](<assets/g-7fXFedbmSrl04-nj_oklIVEGOvguim3tMz1j_QShc=.html; charset=utf-8>)

### 3.2 Component Descriptions

#### 3.2.1 Client Layer

* **Web Interface**: React-based SPA for user interactions
* **Command Line Interface**: Python-based CLI for automation

#### 3.2.2 API Layer

* **API Gateway**: RESTful API endpoints for file operations
* **Authentication**: API key-based authentication for API access

#### 3.2.3 Compute Layer

* **Upload Handler**: Lambda function for secure file uploads
* **Metadata Analyzer**: Lambda function for extracting file metadata
* **Search Handler**: Lambda function for processing search queries
* **Virus Scanner**: Lambda function for malware detection

#### 3.2.4 Storage Layer

* **S3 Bucket**: Primary storage for files
* **DynamoDB Table**: Storage for file metadata and search indices

#### 3.2.5 ML Pipeline

* **Rekognition**: Image analysis and label detection
* **Textract**: Text extraction from documents
* **Custom Document Classifier**: ML model for document categorization

### 3.3 Technology Stack

* **Backend**: Python 3.9, AWS Lambda, AWS SDK
* **Frontend**: React, TypeScript
* **Infrastructure**: AWS CDK, CloudFormation
* **Storage**: S3, DynamoDB
* **ML Services**: Rekognition, Textract, SageMaker (optional)
* **Security**: IAM, Lambda Layer for ClamAV

## 4. Component Specifications

### 4.1 Upload Handler

The Upload Handler Lambda function manages secure file uploads and validation.

#### 4.1.1 Functions

* Generate presigned URLs for direct S3 uploads
* Validate file metadata (size, type, name)
* Trigger virus scanning and metadata extraction
* Update file status in DynamoDB

#### 4.1.2 Interfaces

* **Input**: File metadata (name, size, type)
* **Output**: Presigned URL, file ID, status

#### 4.1.3 Dependencies

* S3 Client
* DynamoDB Client
* FileValidator Module
* Lambda Client (for triggering other functions)

### 4.2 Metadata Analyzer

The Metadata Analyzer Lambda function extracts and processes file metadata.

#### 4.2.1 Functions

* Extract basic file metadata (size, type, etc.)
* Process image files using Rekognition
* Process document files using Textract
* Store extracted metadata in DynamoDB

#### 4.2.2 Interfaces

* **Input**: S3 event notification
* **Output**: Extracted metadata in DynamoDB

#### 4.2.3 Dependencies

* S3 Client
* DynamoDB Client
* Rekognition Client
* Textract Client

### 4.3 Search Handler

The Search Handler Lambda function processes search queries against the metadata database.

#### 4.3.1 Functions

* Parse search query parameters
* Build DynamoDB query expressions
* Process and format search results
* Support pagination and sorting

#### 4.3.2 Interfaces

* **Input**: Search query parameters
* **Output**: Matching file metadata results

#### 4.3.3 Dependencies

* DynamoDB Client
* Query Builder Utility

### 4.4 Virus Scanner

The Virus Scanner Lambda function checks files for malware.

#### 4.4.1 Functions

* Download file from S3
* Scan file using ClamAV
* Quarantine infected files
* Update file status in DynamoDB
* Send alerts for infected files

#### 4.4.2 Interfaces

* **Input**: S3 event notification
* **Output**: Scan results and status update

#### 4.4.3 Dependencies

* S3 Client
* DynamoDB Client
* SNS Client
* ClamAV Lambda Layer

### 4.5 ML Model Monitor

The ML Model Monitor Lambda function tracks model performance and data drift.

#### 4.5.1 Functions

* Monitor data drift in input features
* Track prediction patterns
* Evaluate model performance against ground truth
* Monitor resource utilization
* Generate alerts for anomalies

#### 4.5.2 Interfaces

* **Input**: CloudWatch scheduled event
* **Output**: Monitoring results and alerts

#### 4.5.3 Dependencies

* CloudWatch Client
* S3 Client
* SNS Client
* SageMaker Client
* Statistical Analysis Libraries

## 5. Data Model

### 5.1 File Metadata Schema (DynamoDB)

```
{
  "file_id": String (Primary Key),
  "file_name": String,
  "key": String,
  "bucket": String,
  "size": Number,
  "content_type": String,
  "etag": String,
  "file_hash": String,
  "last_modified": String (ISO timestamp),
  "upload_status": String (processing|available|infected|error),
  "validation_status": String,
  "scan_result": {
    "scan_status": String,
    "threat_detected": Boolean,
    "threat_name": String,
    "scan_timestamp": String
  },
  "labels": [String],
  "text_detected": [String],
  "text_content": [String],
  "analysis_type": String,
  "custom_metadata": Map
}

```

### 5.2 Performance Metrics Schema (CloudWatch)

```
{
  "Metric": String,
  "Value": Number,
  "Timestamp": String,
  "Unit": String,
  "Dimensions": {
    "ServiceName": String,
    "FunctionName": String,
    "ResourceId": String
  }
}

```

### 5.3 ML Model Performance Schema (S3)

```
{
  "model_id": String,
  "timestamp": String,
  "metrics": {
    "accuracy": Number,
    "precision": Number,
    "recall": Number,
    "f1_score": Number
  },
  "confusion_matrix": Object,
  "data_drift": {
    "features": Object,
    "overall_status": String
  },
  "prediction_drift": {
    "js_distance": Number,
    "status": String
  }
}

```

## 6. Data Flow and Processing

### 6.1 File Upload Flow

1. Client requests a presigned URL from Upload Handler
2. Upload Handler validates file metadata
3. Upload Handler returns presigned URL to client
4. Client uploads file directly to S3 using presigned URL
5. Client notifies Upload Handler of completed upload
6. Upload Handler triggers virus scanning
7. If file is clean, Upload Handler triggers metadata extraction
8. Metadata Analyzer processes file and extracts metadata
9. Metadata is stored in DynamoDB
10. File status is updated to "available"

### 6.2 Search Flow

1. Client sends search query to Search Handler
2. Search Handler builds query expression for DynamoDB
3. Search Handler executes query against metadata table
4. Results are formatted and returned to client
5. (Optional) Client requests presigned URL for file download

### 6.3 Virus Scanning Flow

1. Virus Scanner receives notification for new file
2. Virus Scanner downloads file from S3
3. Virus Scanner scans file using ClamAV
4. If file is clean, status is updated to "scanning\_complete"
5. If file is infected:
   * File is moved to quarantine bucket
   * Original file is deleted
   * Status is updated to "infected"
   * Alert is sent via SNS

### 6.4 ML Monitoring Flow

1. Model Monitor runs on scheduled interval
2. Monitor collects recent data and predictions
3. Monitor calculates drift metrics
4. Monitor evaluates performance metrics
5. If anomalies detected, alerts are sent
6. Monitoring results are stored in S3
7. CloudWatch metrics are updated

## 7. Machine Learning Pipeline

### 7.1 Document Classification

#### 7.1.1 Model Architecture

* Base model: DistilBERT fine-tuned for document classification
* Input: Document text extracted by Textract
* Output: Document category with confidence score

#### 7.1.2 Training Pipeline

1. Collect labeled document examples
2. Extract text using Textract
3. Preprocess text (tokenization, etc.)
4. Fine-tune model on SageMaker
5. Evaluate model performance
6. Deploy model to SageMaker endpoint

#### 7.1.3 Inference Pipeline

1. Extract text from uploaded document
2. Preprocess text
3. Call model endpoint for prediction
4. Store prediction and confidence in metadata

### 7.2 Image Analysis

#### 7.2.1 Services

* Rekognition for label detection
* Rekognition for text detection
* Rekognition for object detection

#### 7.2.2 Processing Pipeline

1. Detect labels and objects
2. Detect text in images
3. Calculate scene characteristics
4. Store results in metadata

### 7.3 Model Monitoring

#### 7.3.1 Data Drift Monitoring

* Track feature distributions over time
* Use statistical tests to detect drift
* Calculate JS divergence for categorical features
* Use KS test for numerical features

#### 7.3.2 Performance Monitoring

* Track accuracy, precision, recall, F1 score
* Compare against baseline performance
* Identify problematic classes/categories
* Detect performance degradation trends

## 8. Security Design

### 8.1 Authentication and Authorization

* API key authentication for API access
* IAM roles for service-to-service communication
* Fine-grained permissions for Lambda functions
* Resource-based policies for S3 buckets

### 8.2 Data Protection

* Server-side encryption for S3 objects
* Encryption in transit for all communications
* DynamoDB encryption at rest
* Secure parameter storage for sensitive values

### 8.3 Virus Scanning

* ClamAV integration via Lambda Layer
* Quarantine mechanism for infected files
* Automatic virus definition updates
* Alert system for security incidents

### 8.4 File Validation

* Content type validation
* File size limits
* Malicious signature detection
* Filename sanitization
* MIME type verification

## 9. Performance Considerations

### 9.1 Scalability

* Serverless architecture for automatic scaling
* DynamoDB on-demand capacity mode
* S3 transfer acceleration for large files
* Lambda concurrency limits based on usage patterns

### 9.2 Latency Optimization

* Optimized Lambda memory allocation
* Efficient DynamoDB access patterns
* Presigned URL generation for direct S3 access
* CloudFront for content delivery (optional)

### 9.3 Throughput

* Concurrent upload handling
* Batch processing for metadata extraction
* Query optimization for search
* Connection pooling for database access

## 10. Deployment Strategy

### 10.1 Infrastructure as Code

* AWS CDK for infrastructure definition
* CloudFormation for deployment
* Version-controlled configuration
* Environment-specific parameters

### 10.2 CI/CD Pipeline

* Automated testing before deployment
* Staged deployments (dev, staging, prod)
* Blue/green deployment for zero downtime
* Automated rollbacks for failures

### 10.3 Environment Setup

* Development environment
  * Local testing with SAM CLI
  * Mocked AWS services
  * Debug logging enabled
* Staging environment
  * Full AWS deployment
  * Test data seeding
  * Performance testing
* Production environment
  * Strict security controls
  * Alarms and monitoring
  * Backup procedures

## 11. Testing Strategy

### 11.1 Unit Testing

* Test individual Lambda functions
* Mock AWS services
* Test error handling and edge cases
* Validate input/output formats

### 11.2 Integration Testing

* Test end-to-end workflows
* Validate service interactions
* Test API endpoints
* Verify data consistency

### 11.3 Performance Testing

* Measure request latency
* Test concurrent uploads
* Evaluate search performance
* Stress testing for bottlenecks

### 11.4 ML Model Testing

* Data pipeline validation
* Model training verification
* Inference accuracy testing
* Drift detection testing
* Alert system validation

## 12. Maintenance and Monitoring

### 12.1 Operational Monitoring

* CloudWatch dashboards for system health
* Lambda function metrics
* API Gateway request tracking
* S3 and DynamoDB usage metrics

### 12.2 Error Handling

* Centralized error logging
* Dead letter queues for failed processes
* Automatic retry for transient failures
* Alert system for critical errors

### 12.3 Backup and Recovery

* S3 versioning for file recovery
* DynamoDB point-in-time recovery
* Regular metadata exports
* Disaster recovery procedures

### 12.4 ML Model Maintenance

* Scheduled retraining
* Performance evaluation cycles
* Drift-triggered retraining
* Model versioning system

## 13. Cost Optimization

### 13.1 Free Tier Utilization

* S3: Stay under 5GB storage
* Lambda: Keep within free tier execution limits
* DynamoDB: Use on-demand capacity within free tier
* API Gateway: Stay under 1M requests per month

### 13.2 Resource Optimization

* Right-sized Lambda functions
* Efficient DynamoDB queries
* Optimized S3 storage classes
* Scheduled cleanups for temporary resources

### 13.3 Monitoring Costs

* AWS Cost Explorer setup
* Budget alerts
* Usage tracking
* Cost allocation tags

## 14. Future Enhancements

### 14.1 Feature Roadmap

* Audio file analysis
* Video content analysis
* Advanced document understanding
* Natural language search capabilities
* Multi-user support with permissions

### 14.2 Technical Improvements

* Enhanced ML model performance
* Real-time collaborative editing
* Workflow automation
* Mobile application integration
* Enhanced visualization capabilities

## Appendix A: Implementation Checklist

1. Set up AWS account and configure IAM roles
2. Deploy base infrastructure using CDK
3. Implement Lambda functions
   * Upload Handler
   * Metadata Analyzer
   * Search Handler
   * Virus Scanner
4. Set up S3 buckets and DynamoDB tables
5. Configure API Gateway
6. Implement ML pipeline
7. Set up monitoring and alerting
8. Develop web interface
9. Develop CLI tool
10. Run comprehensive tests
11. Document system for users and administrators

## Appendix B: Configuration Reference

### AWS CDK Configuration

```
// Example CDK configuration
const app = new cdk.App();
const stack = new FileManagerStack(app, 'FileManagerStack', {
  env: {
    region: 'us-east-1',
    account: process.env.CDK_DEFAULT_ACCOUNT,
  },
  storageBucketName: 'file-manager-storage',
  quarantineBucketName: 'file-manager-quarantine',
  metadataTableName: 'file-manager-metadata',
  maxFileSize: 5 * 1024 * 1024 * 1024,  // 5GB
  enableVirusScanning: true,
  enableAdvancedMetadata: true
});

```

### Lambda Configuration

```
# Example Lambda configuration
UploadHandler:
  Runtime: python3.9
  MemorySize: 256
  Timeout: 30
  Environment:
    Variables:
      BUCKET_NAME: file-manager-storage
      TABLE_NAME: file-manager-metadata
      MAX_FILE_SIZE: 5368709120
      VIRUS_SCAN_ENABLED: true

MetadataAnalyzer:
  Runtime: python3.9
  MemorySize: 1024
  Timeout: 300
  Environment:
    Variables:
      TABLE_NAME: file-manager-metadata
      ENABLE_REKOGNITION: true
      ENABLE_TEXTRACT: true

```

### API Gateway Configuration

```
# Example API Gateway configuration
FileManagerApi:
  StageName: prod
  ThrottlingBurstLimit: 100
  ThrottlingRateLimit: 50
  Cors:
    AllowOrigins: '*'
    AllowMethods: 'GET,POST,PUT,DELETE'
    AllowHeaders: '*'

```

## Appendix C: API Reference

### Upload API

#### Generate Presigned URL

```
GET /files/upload
Query Parameters:
  - filename (required): Name of the file
  - contentType (required): MIME type of the file
  - fileSize (required): Size of the file in bytes

Response:
{
  "uploadUrl": "https://...",
  "fileId": "abc123",
  "key": "2025/03/03/abc123/filename.pdf",
  "expiresIn": 3600
}

```

#### Complete Upload

```
POST /files/complete
Body:
{
  "key": "2025/03/03/abc123/filename.pdf"
}

Response:
{
  "message": "File uploaded successfully",
  "fileId": "abc123",
  "status": "processing"
}

```

### Search API

#### Search Files

```
GET /files/search
Query Parameters:
  - query: Search term
  - type: Filter by file type
  - date_from: Filter by date range start
  - date_to: Filter by date range end
  - limit: Maximum number of results
  - last_key: Pagination token

Response:
{
  "results": [
    {
      "file_id": "abc123",
      "file_name": "document.pdf",
      "size": 1024,
      "last_modified": "2025-03-03T12:00:00Z",
      "content_type": "application/pdf",
      "labels": ["invoice", "financial"]
    }
  ],
  "count": 1,
  "last_evaluated_key": "xyz789"
}

```

#### Get File Metadata

```
GET /files/{fileId}/metadata

Response:
{
  "file_id": "abc123",
  "file_name": "document.pdf",
  "size": 1024,
  "last_modified": "2025-03-03T12:00:00Z",
  "content_type": "application/pdf",
  "labels": ["invoice", "financial"],
  "text_content": ["Invoice #12345", "Due: 2025-04-01"],
  "analysis_type": "document"
}

```

#### Get Download URL

```
GET /files/{fileId}/download

Response:
{
  "downloadUrl": "https://...",
  "fileName": "document.pdf",
  "expiresIn": 3600
}

```

## Appendix D: Error Codes

| Code | Description                | HTTP Status |
| ---- | -------------------------- | ----------- |
| 1001 | Invalid file type          | 400         |
| 1002 | File too large             | 400         |
| 1003 | Invalid file name          | 400         |
| 1004 | Virus detected             | 400         |
| 1005 | Upload failed              | 500         |
| 1006 | File not found             | 404         |
| 1007 | Invalid search query       | 400         |
| 1008 | Unauthorized access        | 403         |
| 2001 | Metadata extraction failed | 500         |
| 2002 | Search engine error        | 500         |
| 3001 | ML service unavailable     | 503         |
| 9999 | Internal server error      | 500         |
